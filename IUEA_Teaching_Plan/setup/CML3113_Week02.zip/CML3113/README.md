# CML3113 Week 2

Upload proof_of_life.ipynb and drill_shift_log.csv into Colab. The four numbered notebooks deliberately fail. Diagnose and repair them; do not submit the broken originals. The dataset is a fictional four-row practice fixture, not an engineering benchmark.
