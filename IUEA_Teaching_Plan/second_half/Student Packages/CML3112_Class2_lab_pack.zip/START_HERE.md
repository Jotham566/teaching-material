# CML3112, Class 2 (Week 9): lab pack

1. Open Google Colab and upload `Class2_Lab_Classification.ipynb`.
2. In the Files panel (folder icon) upload `engineering_data.csv`.
3. Run the cells in order with Shift and Enter. Read the PREDICT, READ and CHANGE boxes and type your answers in the lines that start with `>`.
4. At the end choose Runtime, Restart session and run all. If nothing fails, save a copy in Drive.

This notebook is for learning in class. It is not an upload. Your lecturer shares the block assignment separately: it is practice, collected with feedback, and does not count toward your final mark. The Week 12 project uses the same steps.

The data are synthetic teaching data about cooling load (kW).
