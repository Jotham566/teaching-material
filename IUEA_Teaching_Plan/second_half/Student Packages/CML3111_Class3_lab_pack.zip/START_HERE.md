# CML3111, Class 3 (Week 10): lab pack

1. Open Google Colab and upload `Class3_Lab_Trust.ipynb`.
2. In the Files panel (folder icon) upload `engineering_data.csv`.
3. Run the cells in order with Shift and Enter. Read the PREDICT, READ and CHANGE boxes and type your answers in the lines that start with `>`.
4. At the end choose Runtime, Restart session and run all. If nothing fails, save a copy in Drive.

This notebook is for learning in class. It is not an upload. Your lecturer shares the block assignment separately: it is practice, collected with feedback, and does not count toward your final mark. Week 10 is a revision class that works through the project rehearsal, so read these slides and do this lab at home. The Engineering ML project is online, 23 to 25 November.

The data are synthetic teaching data about motor winding temperature (deg C).
