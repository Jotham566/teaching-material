# CML3112 A7 — Regression and baseline

**Submit:** ONE completed assignment notebook (.ipynb).

**Deadline:** 17 November 2026, 11:00 Kampala. The live form shows any later change.

<!-- BLOCK_ASSESSMENT_20261030 -->
**Block assessment:** this is part A of 3 of the Block 1 assignment (Weeks 8 to 10; parts A7, A8, A9). All parts close together at the time above, and each part is marked out of 20. The Block 1 quiz is one sitting: In the last twenty minutes of the Week 10 class the lecturer opens the three quiz forms together; each stays open for 24 hours.

## 1. Start

Open **W08_student.ipynb**. Keep these supporting files beside it: engineering_data.csv.

In Colab: File → Open notebook → Upload. Add any supplied CSV files through the Files sidebar. Save your own copy in Drive.

## 2. Work down the notebook

1. Set STUDENT_ID to your own Student Registration Number, keeping quotes and slashes. Keep COHORT="CML3112".
2. Answer each numbered task immediately below its prompt. Keep the required names exactly as shown.

3. Answer the **Written questions** in the notebook’s **My written evidence** cell. Use your own words. The prompts show the marks.

The written questions use the supplied scenario. Label these as supplied results, not measurements you computed.

## 3. Check and save

Restart and run all cells from the top. Fix errors, then download/save the completed notebook. For the filename only, replace slashes in your registration number with underscores and add _W08.ipynb.

## 4. Hand in

Open your cohort’s form below. Enter your Student Registration Number. Choose **Add file → Upload**, attach the required file(s), then press **Submit**. Keep the confirmation.

For individual work, leave Team ID blank. Each file must be at most 10 MB. A replacement before the deadline must contain the complete file set again.

**Do not submit:** the ZIP, guided_practice.ipynb, raw CSVs or helper scripts.

**Submission link:** https://docs.google.com/forms/d/e/1FAIpQLSfOpt4U_rhJrjlYCp6pyzm9ygu2vN5EwO9yeAiJaUKy-kJKoA/viewform

## Help only if needed

Need help opening, saving or uploading? Use STUDENT_HOW_TO.md only for the step you are stuck on. It is a reference, not extra homework.

<!-- PANDAS_WORKFLOW_20261015 -->
## Pandas workflow

Run the supplied pandas loading cell first. Analyse tables with pandas inside the required functions; return the exact list or dictionary requested. Where supplied, use records_from_table when a return needs Python None values. Correct existing loop-based solutions remain accepted.
