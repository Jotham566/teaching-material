# CML3112 A8: Classification and cost

**Block 1, part B of 2** (Weeks 8 and 9 content). Marked out of 20. All 2 parts of the block close together.

**Deadline:** 17 November 2026, 11:00 Kampala. The live form shows any later change.
**Submit:** ONE completed notebook (.ipynb) on this form: https://docs.google.com/forms/d/e/1FAIpQLSfTe7OkZ7tZEVzG-mup0-8liXg1jKy_KmsDWZiPK9EWMJ9InA/viewform
**Block quiz:** one sitting in the last 20 minutes of Class 2 (Tuesday 10 November), 2 short quizzes, 10 marks.

**Does this count?** No. From 10 November 2026 the Week 8 to 11 block assignments (A7 to A11) and block quizzes (Q7 to Q10) are practice and do not count toward your final mark (only A1 to A5 and Q1 to Q5 count). Still do the work: it is collected, you get feedback, and it prepares you for the project sitting.

## Do this

1. Keep these files together: W09_student.ipynb, classification_case.csv, engineering_data.csv. In Colab choose File, then Open notebook, then Upload, and add the CSV files in the Files sidebar.
2. Run the data-loading cell first. Set STUDENT_ID to your Student Registration Number, keeping quotes and slashes. Keep COHORT="CML3112".
3. Answer each numbered task under its prompt, keeping the required names. Use pandas inside the functions and return the published types.
4. Answer the written questions in the "My written evidence" cell in your own words. Label any supplied results as supplied.
5. Restart and run all cells from the top, then fix any errors.
6. Save the notebook as your registration number with slashes replaced by underscores, then _W09.ipynb.
7. Open the form, enter your Student Registration Number, upload the notebook, press Submit and keep the confirmation.

## Rules

- Submit only the notebook. Do not submit the ZIP, guided_practice.ipynb or the CSV files.
- Leave Team ID blank. The file must be at most 10 MB. A resubmission before the deadline replaces the earlier one and must be the complete notebook.
- guided_practice.ipynb is for practice in class. It is not marked.
- A part that is not submitted gets no feedback. Submit each part as you finish it.
