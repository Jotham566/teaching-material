# CML3112 A10: Features and ablation

**Block 2, part B of 3** (Weeks 10 and 11 content). Marked out of 20. All 3 parts of the block close together.

**Deadline:** 1 December 2026, 11:00 Kampala. The live form shows any later change.
**Submit:** ONE completed notebook (.ipynb) on this form: https://docs.google.com/forms/d/e/1FAIpQLSfSqUcR9TgY7f1c7HXO9KGM3C2yXm1r7V2rQl2WEubwZir8iw/viewform
**Block quiz:** one sitting in the last 20 minutes of Class 4 (Tuesday 24 November), 2 short quizzes, 10 marks.

## Do this

1. Keep these files together: W11_student.ipynb, engineering_data.csv. In Colab choose File, then Open notebook, then Upload, and add the CSV files in the Files sidebar.
2. Run the data-loading cell first. Set STUDENT_ID to your Student Registration Number, keeping quotes and slashes. Keep COHORT="CML3112".
3. Answer each numbered task under its prompt, keeping the required names. Use pandas inside the functions and return the published types.
4. Answer the written questions in the "My written evidence" cell in your own words. Label any supplied results as supplied.
5. Restart and run all cells from the top, then fix any errors.
6. Save the notebook as your registration number with slashes replaced by underscores, then _W11.ipynb.
7. Open the form, enter your Student Registration Number, upload the notebook, press Submit and keep the confirmation.

## Rules

- Submit only the notebook. Do not submit the ZIP, guided_practice.ipynb or the CSV files.
- Leave Team ID blank. The file must be at most 10 MB. A resubmission before the deadline replaces the earlier one and must be the complete notebook.
- guided_practice.ipynb is for practice in class. It is not marked.
- A part that is not submitted scores zero. Submit each part as you finish it.
